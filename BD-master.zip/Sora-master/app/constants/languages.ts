const languages: string[] = ['en', 'fr', 'vi'];

export default languages;
