const episodeTypes = [
  {
    activeType: 0,
    activeTypeName: 'Number',
  },
  {
    activeType: 1,
    activeTypeName: 'Image',
  },
];

export default episodeTypes;
