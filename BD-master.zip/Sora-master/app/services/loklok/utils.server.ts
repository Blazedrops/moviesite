import { env } from 'process';

// eslint-disable-next-line import/prefer-default-export
export const LOKLOK_URL = env.LOKLOK_API_URL;
