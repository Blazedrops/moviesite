const CharactersPage = () => (
  <div className="flex w-full flex-col items-center justify-center px-3 sm:px-5">
    <h4>In development</h4>
  </div>
);

export default CharactersPage;
