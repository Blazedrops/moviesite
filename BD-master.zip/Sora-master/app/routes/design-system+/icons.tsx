const IconsPage = () => {
  return (
    <>
      <h2>Icons</h2>
    </>
  );
};

export default IconsPage;
