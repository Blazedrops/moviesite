const SearchIndexPage = () => <h4> Choose a search.</h4>;

export default SearchIndexPage;
